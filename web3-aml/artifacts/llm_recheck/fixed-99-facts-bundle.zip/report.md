# Web3 AML 风险分析报告

## 1. 地址风险概述

- 地址 17m7vN4jkWEAVvDZ537F36wQiENgxLnyhM 的综合模型风险为 0.08 / 100，等级 LOW。这是模型预测。 [E01](#evidence-e01)
- 行为画像单组诊断分为 2.65 / 100，用于解释证据职责，综合评分由联合模型产生。 [E02](#evidence-e02)
- 方向邻域偏离单组诊断分为 5.20 / 100，用于解释证据职责，综合评分由联合模型产生。 [E03](#evidence-e03)
- 有向结构角色单组诊断分为 0.44 / 100，用于解释证据职责，综合评分由联合模型产生。 [E04](#evidence-e04)

## 2. 行为风险证据

- fees\_as\_share\_max：原始值 0.0002，联合模型 TreeSHAP贡献 0.7262；贡献解释模型原始输出。 [E05](#evidence-e05)
- 手续费最小值：原始值 0.0783，联合模型 TreeSHAP贡献 -0.4349；贡献解释模型原始输出。 [E06](#evidence-e06)
- transacted\_w\_address\_total：原始值 63.0000，联合模型 TreeSHAP贡献 -0.2193；贡献解释模型原始输出。 [E07](#evidence-e07)
- 手续费最大值：原始值 0.0783，联合模型 TreeSHAP贡献 0.1015；贡献解释模型原始输出。 [E08](#evidence-e08)
- fees\_as\_share\_total：原始值 0.0002，联合模型 TreeSHAP贡献 0.0926；贡献解释模型原始输出。 [E09](#evidence-e09)

## 3. 图结构风险证据

- 下游标准化偏离 · BTC 接收总量：模型输入值 -0.6482，联合模型 TreeSHAP贡献 -0.0754；贡献解释模型原始输出。 [E10](#evidence-e10)
- 上游标准化偏离 · 手续费总额：模型输入值 0.0000，联合模型 TreeSHAP贡献 -0.0753；贡献解释模型原始输出。 [E11](#evidence-e11)
- 上游标准化偏离 · BTC 单次交易最小值：模型输入值 0.0000，联合模型 TreeSHAP贡献 -0.0499；贡献解释模型原始输出。 [E12](#evidence-e12)
- 上游标准化偏离 · fees\_as\_share\_min：模型输入值 0.0000，联合模型 TreeSHAP贡献 -0.0391；贡献解释模型原始输出。 [E13](#evidence-e13)
- 下游标准化偏离 · fees\_as\_share\_max：模型输入值 -0.4602，联合模型 TreeSHAP贡献 -0.0364；贡献解释模型原始输出。 [E14](#evidence-e14)
- 下游平均连接度对数：模型输入值 4.7797，联合模型 TreeSHAP贡献 -0.5210；贡献解释模型原始输出。 [E15](#evidence-e15)
- 出度对数：模型输入值 4.1589，联合模型 TreeSHAP贡献 -0.3091；贡献解释模型原始输出。 [E16](#evidence-e16)
- log\_forward\_two\_step\_walks：模型输入值 8.0631，联合模型 TreeSHAP贡献 -0.2917；贡献解释模型原始输出。 [E17](#evidence-e17)
- mean\_upstream\_log\_out\_degree：模型输入值 0.0000，联合模型 TreeSHAP贡献 0.2202；贡献解释模型原始输出。 [E18](#evidence-e18)
- mean\_downstream\_log\_in\_degree：模型输入值 4.7627，联合模型 TreeSHAP贡献 -0.1424；贡献解释模型原始输出。 [E19](#evidence-e19)
- 出度为 63，描述图结构关联。 [E20](#evidence-e20)
- 入度为 0，描述图结构关联。 [E21](#evidence-e21)
- 一跳邻居数为 63，描述图结构关联。 [E22](#evidence-e22)
- 一跳邻居平均风险为 2.50，描述图结构关联。 [E23](#evidence-e23)
- 一跳高风险邻居数为 0，描述图结构关联。 [E24](#evidence-e24)
- 一跳高风险邻居比例为 0.0000，描述图结构关联。 [E25](#evidence-e25)
- 二跳采样平均风险为 1.75，描述图结构关联。 [E26](#evidence-e26)
- 二跳采样高风险比例为 0.0000，描述图结构关联。 [E27](#evidence-e27)
- 二跳采样节点数为 200，描述图结构关联。 [E28](#evidence-e28)

## 4. 可疑关联路径

- 关系路径 1：17m7vN4jkWEAVvDZ537F36wQiENgxLnyhM → 1Fac1iyWwnAzjbZFD5qg1qTb9TuU5P2hpU → 19UuR2CRVLjEkhu3aA5gJ179dbTjCTTYGJ → 37p9pUugydmoLpQyFLLqGAgjWmUFERa1Pq → 13hB6VxWn52YuzXJJ9FE6Y7NVnT5CtRjmD，共 4 跳、5 个不同地址；搜索排序分 0.2375。路径表示有向关联，排序分用于候选排序。 路径来源编号 trace\_7657d6f835332ddf82825440。 [E29](#evidence-e29)
- 路径第 0 跳地址 17m7vN4jkWEAVvDZ537F36wQiENgxLnyhM 的原始风险为 0.08 / 100。 [E30](#evidence-e30)
- 路径第 1 跳地址 1Fac1iyWwnAzjbZFD5qg1qTb9TuU5P2hpU 的原始风险为 15.00 / 100。 [E31](#evidence-e31)
- 路径第 2 跳地址 19UuR2CRVLjEkhu3aA5gJ179dbTjCTTYGJ 的原始风险为 2.42 / 100。 [E32](#evidence-e32)
- 路径第 3 跳地址 37p9pUugydmoLpQyFLLqGAgjWmUFERa1Pq 的原始风险为 47.35 / 100。 [E33](#evidence-e33)
- 路径第 4 跳地址 13hB6VxWn52YuzXJJ9FE6Y7NVnT5CtRjmD 的原始风险为 65.03 / 100。 [E34](#evidence-e34)
- 低分连接从 1Fac1iyWwnAzjbZFD5qg1qTb9TuU5P2hpU 开始，共 2 个连续低分节点；存在到 37p9pUugydmoLpQyFLLqGAgjWmUFERa1Pq 的完整有向连接见证。 首个低分节点风险 15.00，锚点原始风险 47.35；节点原始评分保持不变。 [E35](#evidence-e35)
- 关系路径 2：17m7vN4jkWEAVvDZ537F36wQiENgxLnyhM → … → 3Kfke8cAB7fbxnBmpSyWtK6tWMFFt1frzs（完整地址见对应证据），共 11 跳、12 个不同地址；搜索排序分 0.0943。路径表示有向关联，排序分用于候选排序。 路径来源编号 trace\_9d0e3bfc3196f86d0ce15995。 [E36](#evidence-e36)
- 路径第 0 跳地址 17m7vN4jkWEAVvDZ537F36wQiENgxLnyhM 的原始风险为 0.08 / 100。 [E37](#evidence-e37)
- 路径第 1 跳地址 1G5y49HMWBGtoSFEQx4B2Vg13knyJBBhfR 的原始风险为 15.29 / 100。 [E38](#evidence-e38)
- 路径第 2 跳地址 1Em69Tj8u3mnd5ujLmks5JiAq8dwgdjM4G 的原始风险为 7.43 / 100。 [E39](#evidence-e39)
- 路径第 3 跳地址 14ccu2pkDey82MgWYB6eqwsxvAGtj5n7Bp 的原始风险为 33.77 / 100。 [E40](#evidence-e40)
- 路径第 4 跳地址 1ErSPkXKfdVgjseia1psccr6ng4zbyLNSE 的原始风险为 15.61 / 100。 [E41](#evidence-e41)
- 路径第 5 跳地址 19ve3JWXnvMCeFaKoWpXQ8mHJxT5DHyHU2 的原始风险为 14.53 / 100。 [E42](#evidence-e42)
- 路径第 6 跳地址 1FRCAsP1c12HCjgGdTYDgwLnrwyA6dFwRE 的原始风险为 14.45 / 100。 [E43](#evidence-e43)
- 路径第 7 跳地址 1G55jNLdZ3kQ5dhQEcRtrSy6yW3kMXvv8b 的原始风险为 42.55 / 100。 [E44](#evidence-e44)
- 路径第 8 跳地址 1NoXFU871W3LZjKVkb284JVMXj24afQis3 的原始风险为 1.36 / 100。 [E45](#evidence-e45)
- 路径第 9 跳地址 1LXzGFMKxm5QGMkys7iBxVRabxwdFASXsM 的原始风险为 1.11 / 100。 [E46](#evidence-e46)
- 路径第 10 跳地址 32TmSYcBDp9hG8rosH6vQB4uoNbJKXbkaZ 的原始风险为 4.09 / 100。 [E47](#evidence-e47)
- 路径第 11 跳地址 3Kfke8cAB7fbxnBmpSyWtK6tWMFFt1frzs 的原始风险为 36.05 / 100。 [E48](#evidence-e48)
- 低分连接从 1G5y49HMWBGtoSFEQx4B2Vg13knyJBBhfR 开始，共 2 个连续低分节点；存在到 14ccu2pkDey82MgWYB6eqwsxvAGtj5n7Bp 的完整有向连接见证。 首个低分节点风险 15.29，锚点原始风险 33.77；节点原始评分保持不变。 [E49](#evidence-e49)
- 低分连接从 1ErSPkXKfdVgjseia1psccr6ng4zbyLNSE 开始，共 3 个连续低分节点；存在到 1G55jNLdZ3kQ5dhQEcRtrSy6yW3kMXvv8b 的完整有向连接见证。 首个低分节点风险 15.61，锚点原始风险 42.55；节点原始评分保持不变。 [E50](#evidence-e50)
- 低分连接从 1NoXFU871W3LZjKVkb284JVMXj24afQis3 开始，共 3 个连续低分节点；存在到 3Kfke8cAB7fbxnBmpSyWtK6tWMFFt1frzs 的完整有向连接见证。 首个低分节点风险 1.36，锚点原始风险 36.05；节点原始评分保持不变。 [E51](#evidence-e51)
- 关系路径 3：17m7vN4jkWEAVvDZ537F36wQiENgxLnyhM → … → 1A6j6upsJfTAt3biLvk8NVvbPitqZtMJ1D（完整地址见对应证据），共 6 跳、7 个不同地址；搜索排序分 0.1609。路径表示有向关联，排序分用于候选排序。 路径来源编号 trace\_c30b57327fc7f0e91f2c1c43。 [E52](#evidence-e52)
- 路径第 0 跳地址 17m7vN4jkWEAVvDZ537F36wQiENgxLnyhM 的原始风险为 0.08 / 100。 [E53](#evidence-e53)
- 路径第 1 跳地址 1Fac1iyWwnAzjbZFD5qg1qTb9TuU5P2hpU 的原始风险为 15.00 / 100。 [E54](#evidence-e54)
- 路径第 2 跳地址 19UuR2CRVLjEkhu3aA5gJ179dbTjCTTYGJ 的原始风险为 2.42 / 100。 [E55](#evidence-e55)
- 路径第 3 跳地址 37p9pUugydmoLpQyFLLqGAgjWmUFERa1Pq 的原始风险为 47.35 / 100。 [E56](#evidence-e56)
- 路径第 4 跳地址 1Kv7F8hg84u7adFm145KUqz6BuTkDxBgEY 的原始风险为 4.12 / 100。 [E57](#evidence-e57)
- 路径第 5 跳地址 1L5aGbkcbyHNNrjZExsT7ABcprQrzQDTJ4 的原始风险为 6.22 / 100。 [E58](#evidence-e58)
- 路径第 6 跳地址 1A6j6upsJfTAt3biLvk8NVvbPitqZtMJ1D 的原始风险为 42.39 / 100。 [E59](#evidence-e59)
- 低分连接从 1Fac1iyWwnAzjbZFD5qg1qTb9TuU5P2hpU 开始，共 2 个连续低分节点；存在到 37p9pUugydmoLpQyFLLqGAgjWmUFERa1Pq 的完整有向连接见证。 首个低分节点风险 15.00，锚点原始风险 47.35；节点原始评分保持不变。 [E60](#evidence-e60)
- 低分连接从 1Kv7F8hg84u7adFm145KUqz6BuTkDxBgEY 开始，共 2 个连续低分节点；存在到 1A6j6upsJfTAt3biLvk8NVvbPitqZtMJ1D 的完整有向连接见证。 首个低分节点风险 4.12，锚点原始风险 42.39；节点原始评分保持不变。 [E61](#evidence-e61)
- 关系路径 4：17m7vN4jkWEAVvDZ537F36wQiENgxLnyhM → … → 3Kfke8cAB7fbxnBmpSyWtK6tWMFFt1frzs（完整地址见对应证据），共 10 跳、11 个不同地址；搜索排序分 0.0998。路径表示有向关联，排序分用于候选排序。 路径来源编号 trace\_b3f021391f7abfd5cf8e55bf。 [E62](#evidence-e62)
- 路径第 0 跳地址 17m7vN4jkWEAVvDZ537F36wQiENgxLnyhM 的原始风险为 0.08 / 100。 [E63](#evidence-e63)
- 路径第 1 跳地址 1G5y49HMWBGtoSFEQx4B2Vg13knyJBBhfR 的原始风险为 15.29 / 100。 [E64](#evidence-e64)
- 路径第 2 跳地址 1Em69Tj8u3mnd5ujLmks5JiAq8dwgdjM4G 的原始风险为 7.43 / 100。 [E65](#evidence-e65)
- 路径第 3 跳地址 14ccu2pkDey82MgWYB6eqwsxvAGtj5n7Bp 的原始风险为 33.77 / 100。 [E66](#evidence-e66)
- 路径第 4 跳地址 1CneiLxRzxGXJEQwVHjegGNtFJRoVF2mxv 的原始风险为 14.35 / 100。 [E67](#evidence-e67)
- 路径第 5 跳地址 1FRCAsP1c12HCjgGdTYDgwLnrwyA6dFwRE 的原始风险为 14.45 / 100。 [E68](#evidence-e68)
- 路径第 6 跳地址 1G55jNLdZ3kQ5dhQEcRtrSy6yW3kMXvv8b 的原始风险为 42.55 / 100。 [E69](#evidence-e69)
- 路径第 7 跳地址 1NoXFU871W3LZjKVkb284JVMXj24afQis3 的原始风险为 1.36 / 100。 [E70](#evidence-e70)
- 路径第 8 跳地址 1LXzGFMKxm5QGMkys7iBxVRabxwdFASXsM 的原始风险为 1.11 / 100。 [E71](#evidence-e71)
- 路径第 9 跳地址 32TmSYcBDp9hG8rosH6vQB4uoNbJKXbkaZ 的原始风险为 4.09 / 100。 [E72](#evidence-e72)
- 路径第 10 跳地址 3Kfke8cAB7fbxnBmpSyWtK6tWMFFt1frzs 的原始风险为 36.05 / 100。 [E73](#evidence-e73)
- 低分连接从 1G5y49HMWBGtoSFEQx4B2Vg13knyJBBhfR 开始，共 2 个连续低分节点；存在到 14ccu2pkDey82MgWYB6eqwsxvAGtj5n7Bp 的完整有向连接见证。 首个低分节点风险 15.29，锚点原始风险 33.77；节点原始评分保持不变。 [E74](#evidence-e74)
- 低分连接从 1CneiLxRzxGXJEQwVHjegGNtFJRoVF2mxv 开始，共 2 个连续低分节点；存在到 1G55jNLdZ3kQ5dhQEcRtrSy6yW3kMXvv8b 的完整有向连接见证。 首个低分节点风险 14.35，锚点原始风险 42.55；节点原始评分保持不变。 [E75](#evidence-e75)
- 低分连接从 1NoXFU871W3LZjKVkb284JVMXj24afQis3 开始，共 3 个连续低分节点；存在到 3Kfke8cAB7fbxnBmpSyWtK6tWMFFt1frzs 的完整有向连接见证。 首个低分节点风险 1.36，锚点原始风险 36.05；节点原始评分保持不变。 [E76](#evidence-e76)
- 关系路径 5：17m7vN4jkWEAVvDZ537F36wQiENgxLnyhM → … → 3Kfke8cAB7fbxnBmpSyWtK6tWMFFt1frzs（完整地址见对应证据），共 10 跳、11 个不同地址；搜索排序分 0.0977。路径表示有向关联，排序分用于候选排序。 路径来源编号 trace\_3c9876ef38bbb581cd35a21d。 [E77](#evidence-e77)
- 路径第 0 跳地址 17m7vN4jkWEAVvDZ537F36wQiENgxLnyhM 的原始风险为 0.08 / 100。 [E78](#evidence-e78)
- 路径第 1 跳地址 1G5y49HMWBGtoSFEQx4B2Vg13knyJBBhfR 的原始风险为 15.29 / 100。 [E79](#evidence-e79)
- 路径第 2 跳地址 1Em69Tj8u3mnd5ujLmks5JiAq8dwgdjM4G 的原始风险为 7.43 / 100。 [E80](#evidence-e80)
- 路径第 3 跳地址 14ccu2pkDey82MgWYB6eqwsxvAGtj5n7Bp 的原始风险为 33.77 / 100。 [E81](#evidence-e81)
- 路径第 4 跳地址 131pig1fU9dAG8npG2vMoJJPraLsqcwU49 的原始风险为 11.10 / 100。 [E82](#evidence-e82)
- 路径第 5 跳地址 1FRCAsP1c12HCjgGdTYDgwLnrwyA6dFwRE 的原始风险为 14.45 / 100。 [E83](#evidence-e83)
- 路径第 6 跳地址 1G55jNLdZ3kQ5dhQEcRtrSy6yW3kMXvv8b 的原始风险为 42.55 / 100。 [E84](#evidence-e84)
- 路径第 7 跳地址 1NoXFU871W3LZjKVkb284JVMXj24afQis3 的原始风险为 1.36 / 100。 [E85](#evidence-e85)
- 路径第 8 跳地址 1LXzGFMKxm5QGMkys7iBxVRabxwdFASXsM 的原始风险为 1.11 / 100。 [E86](#evidence-e86)
- 路径第 9 跳地址 32TmSYcBDp9hG8rosH6vQB4uoNbJKXbkaZ 的原始风险为 4.09 / 100。 [E87](#evidence-e87)
- 路径第 10 跳地址 3Kfke8cAB7fbxnBmpSyWtK6tWMFFt1frzs 的原始风险为 36.05 / 100。 [E88](#evidence-e88)
- 低分连接从 1G5y49HMWBGtoSFEQx4B2Vg13knyJBBhfR 开始，共 2 个连续低分节点；存在到 14ccu2pkDey82MgWYB6eqwsxvAGtj5n7Bp 的完整有向连接见证。 首个低分节点风险 15.29，锚点原始风险 33.77；节点原始评分保持不变。 [E89](#evidence-e89)
- 低分连接从 131pig1fU9dAG8npG2vMoJJPraLsqcwU49 开始，共 2 个连续低分节点；存在到 1G55jNLdZ3kQ5dhQEcRtrSy6yW3kMXvv8b 的完整有向连接见证。 首个低分节点风险 11.10，锚点原始风险 42.55；节点原始评分保持不变。 [E90](#evidence-e90)
- 低分连接从 1NoXFU871W3LZjKVkb284JVMXj24afQis3 开始，共 3 个连续低分节点；存在到 3Kfke8cAB7fbxnBmpSyWtK6tWMFFt1frzs 的完整有向连接见证。 首个低分节点风险 1.36，锚点原始风险 36.05；节点原始评分保持不变。 [E91](#evidence-e91)
- 在线关系检查上限 2000，实际检查 757；停止原因 NO\_ELIGIBLE\_EXPANSIONS。这是搜索范围记录。 [E92](#evidence-e92)

## 5. 综合研判

- 建议结合模型评分、模型归因、图结构与关系路径进行人工复核。 [E93](#evidence-e93)

## 6. 风险提示与系统局限

- 地址风险是模型预测，不能作为犯罪认定或真实身份结论。 [E94](#evidence-e94)
- 路径表示地址有向关系，不能据此认定同一笔资金连续流动、交易金额或逐笔时间。 [E95](#evidence-e95)
- 搜索受深度与预算限制，未展示关系不代表该关系不存在。 [E96](#evidence-e96)
- 模型归因解释相应模型原始输出，贡献不具有因果含义；单组评分用于诊断。 [E97](#evidence-e97)
- 校准依赖已知标签验证集，不能保证未知标签地址的概率校准。 [E98](#evidence-e98)
- 公开数据可能缺少或包含未知标签；地址生命周期汇总特征不等同历史时点实时预测。 [E99](#evidence-e99)

## 证据定位索引

### evidence-e01

E01 · E_90c4edc23ee9b4fb · `/risk_analysis/overall_score`、`/risk_analysis/risk_level`

### evidence-e02

E02 · E_10ec3320c5a8c168 · `/scoring_analysis/route_scores/behavior`

### evidence-e03

E03 · E_60a377864b6a3695 · `/scoring_analysis/route_scores/context`

### evidence-e04

E04 · E_0c4905aaea253285 · `/scoring_analysis/route_scores/structure`

### evidence-e05

E05 · E_ea8d7373262e57f3 · `/scoring_analysis/evidence/behavior/0`

### evidence-e06

E06 · E_523e033fe15583ae · `/scoring_analysis/evidence/behavior/1`

### evidence-e07

E07 · E_49d02368eb7cf318 · `/scoring_analysis/evidence/behavior/2`

### evidence-e08

E08 · E_0eb73050fa072d41 · `/scoring_analysis/evidence/behavior/3`

### evidence-e09

E09 · E_5d2adadb20254b76 · `/scoring_analysis/evidence/behavior/4`

### evidence-e10

E10 · E_c95fdc1972efcc5b · `/scoring_analysis/evidence/context/0`

### evidence-e11

E11 · E_f50e586ed35a36ab · `/scoring_analysis/evidence/context/1`

### evidence-e12

E12 · E_270a52c50bf6566b · `/scoring_analysis/evidence/context/2`

### evidence-e13

E13 · E_79f11d97cba337e7 · `/scoring_analysis/evidence/context/3`

### evidence-e14

E14 · E_ef46d77068d06951 · `/scoring_analysis/evidence/context/4`

### evidence-e15

E15 · E_d32d4ec6118a1194 · `/scoring_analysis/evidence/structure/0`

### evidence-e16

E16 · E_bab4b54d64adf8d9 · `/scoring_analysis/evidence/structure/1`

### evidence-e17

E17 · E_2972b9b70f0b2028 · `/scoring_analysis/evidence/structure/2`

### evidence-e18

E18 · E_03566cd45eb95a59 · `/scoring_analysis/evidence/structure/3`

### evidence-e19

E19 · E_25f90a9c86a56b6c · `/scoring_analysis/evidence/structure/4`

### evidence-e20

E20 · E_e9b7b59053abca1b · `/graph_evidence/out_degree`

### evidence-e21

E21 · E_21bf1c39ea291af3 · `/graph_evidence/in_degree`

### evidence-e22

E22 · E_4a92c567de8fc07f · `/graph_evidence/one_hop_neighbor_count`

### evidence-e23

E23 · E_c439c6660caaf24c · `/graph_evidence/one_hop_avg_risk`

### evidence-e24

E24 · E_954ffcd758970b83 · `/graph_evidence/one_hop_high_risk_count`

### evidence-e25

E25 · E_aa16c5347f510026 · `/graph_evidence/one_hop_high_risk_ratio`

### evidence-e26

E26 · E_09f2bd73817e5cf2 · `/graph_evidence/two_hop_avg_risk`

### evidence-e27

E27 · E_ac9db45d85554168 · `/graph_evidence/two_hop_high_risk_ratio`

### evidence-e28

E28 · E_53794810f397f6c9 · `/graph_evidence/two_hop_sample_count`

### evidence-e29

E29 · E_947365ecbf51cd36 · `/trace_analysis/top_paths/0`

### evidence-e30

E30 · E_7ba119c8f28c4e7f · `/trace_analysis/top_paths/0/node_risks/0`、`/trace_analysis/top_paths/0/nodes/0`

### evidence-e31

E31 · E_b9ab3230cd86734f · `/trace_analysis/top_paths/0/node_risks/1`、`/trace_analysis/top_paths/0/nodes/1`

### evidence-e32

E32 · E_f812b2e3e407364d · `/trace_analysis/top_paths/0/node_risks/2`、`/trace_analysis/top_paths/0/nodes/2`

### evidence-e33

E33 · E_0dc92078e7dae12a · `/trace_analysis/top_paths/0/node_risks/3`、`/trace_analysis/top_paths/0/nodes/3`

### evidence-e34

E34 · E_0174d47a3c3cb626 · `/trace_analysis/top_paths/0/node_risks/4`、`/trace_analysis/top_paths/0/nodes/4`

### evidence-e35

E35 · E_a1d54d0633f4712f · `/trace_analysis/top_paths/0/bridge_witnesses/0`、`/trace_analysis/top_paths/0/node_risks/0`、`/trace_analysis/top_paths/0/node_risks/1`、`/trace_analysis/top_paths/0/node_risks/2`、`/trace_analysis/top_paths/0/node_risks/3`

### evidence-e36

E36 · E_0d1161768b10260d · `/trace_analysis/top_paths/1`

### evidence-e37

E37 · E_fa88ae06b5d5334f · `/trace_analysis/top_paths/1/node_risks/0`、`/trace_analysis/top_paths/1/nodes/0`

### evidence-e38

E38 · E_849fdeeb58119360 · `/trace_analysis/top_paths/1/node_risks/1`、`/trace_analysis/top_paths/1/nodes/1`

### evidence-e39

E39 · E_cf012214ee03a608 · `/trace_analysis/top_paths/1/node_risks/2`、`/trace_analysis/top_paths/1/nodes/2`

### evidence-e40

E40 · E_dc5be9f3a70e460e · `/trace_analysis/top_paths/1/node_risks/3`、`/trace_analysis/top_paths/1/nodes/3`

### evidence-e41

E41 · E_aedf2998d910427f · `/trace_analysis/top_paths/1/node_risks/4`、`/trace_analysis/top_paths/1/nodes/4`

### evidence-e42

E42 · E_ec56b1a9c9292341 · `/trace_analysis/top_paths/1/node_risks/5`、`/trace_analysis/top_paths/1/nodes/5`

### evidence-e43

E43 · E_a21c804d202ced0e · `/trace_analysis/top_paths/1/node_risks/6`、`/trace_analysis/top_paths/1/nodes/6`

### evidence-e44

E44 · E_de1d3ace4c3640c1 · `/trace_analysis/top_paths/1/node_risks/7`、`/trace_analysis/top_paths/1/nodes/7`

### evidence-e45

E45 · E_80ca17dd65c24b38 · `/trace_analysis/top_paths/1/node_risks/8`、`/trace_analysis/top_paths/1/nodes/8`

### evidence-e46

E46 · E_23695b64b988c224 · `/trace_analysis/top_paths/1/node_risks/9`、`/trace_analysis/top_paths/1/nodes/9`

### evidence-e47

E47 · E_3b051206308877b3 · `/trace_analysis/top_paths/1/node_risks/10`、`/trace_analysis/top_paths/1/nodes/10`

### evidence-e48

E48 · E_4c12e6ac895dd2f2 · `/trace_analysis/top_paths/1/node_risks/11`、`/trace_analysis/top_paths/1/nodes/11`

### evidence-e49

E49 · E_c54f90586ef6bb06 · `/trace_analysis/top_paths/1/bridge_witnesses/0`、`/trace_analysis/top_paths/1/node_risks/0`、`/trace_analysis/top_paths/1/node_risks/1`、`/trace_analysis/top_paths/1/node_risks/2`、`/trace_analysis/top_paths/1/node_risks/3`

### evidence-e50

E50 · E_2f5fe0fe0fe4d10d · `/trace_analysis/top_paths/1/bridge_witnesses/1`、`/trace_analysis/top_paths/1/node_risks/3`、`/trace_analysis/top_paths/1/node_risks/4`、`/trace_analysis/top_paths/1/node_risks/5`、`/trace_analysis/top_paths/1/node_risks/6`、`/trace_analysis/top_paths/1/node_risks/7`

### evidence-e51

E51 · E_c1376dc4ec07ef71 · `/trace_analysis/top_paths/1/bridge_witnesses/2`、`/trace_analysis/top_paths/1/node_risks/7`、`/trace_analysis/top_paths/1/node_risks/8`、`/trace_analysis/top_paths/1/node_risks/9`、`/trace_analysis/top_paths/1/node_risks/10`、`/trace_analysis/top_paths/1/node_risks/11`

### evidence-e52

E52 · E_df48c64403d830f5 · `/trace_analysis/top_paths/2`

### evidence-e53

E53 · E_fe1e41ca14c102ef · `/trace_analysis/top_paths/2/node_risks/0`、`/trace_analysis/top_paths/2/nodes/0`

### evidence-e54

E54 · E_1bc310c5fa6018da · `/trace_analysis/top_paths/2/node_risks/1`、`/trace_analysis/top_paths/2/nodes/1`

### evidence-e55

E55 · E_df1ac198bd33ec8e · `/trace_analysis/top_paths/2/node_risks/2`、`/trace_analysis/top_paths/2/nodes/2`

### evidence-e56

E56 · E_072a1aca38fc18e3 · `/trace_analysis/top_paths/2/node_risks/3`、`/trace_analysis/top_paths/2/nodes/3`

### evidence-e57

E57 · E_199204a217dd69f2 · `/trace_analysis/top_paths/2/node_risks/4`、`/trace_analysis/top_paths/2/nodes/4`

### evidence-e58

E58 · E_ff5276f9a8d60b99 · `/trace_analysis/top_paths/2/node_risks/5`、`/trace_analysis/top_paths/2/nodes/5`

### evidence-e59

E59 · E_94a3ba56408006dc · `/trace_analysis/top_paths/2/node_risks/6`、`/trace_analysis/top_paths/2/nodes/6`

### evidence-e60

E60 · E_44e301e75ea72411 · `/trace_analysis/top_paths/2/bridge_witnesses/0`、`/trace_analysis/top_paths/2/node_risks/0`、`/trace_analysis/top_paths/2/node_risks/1`、`/trace_analysis/top_paths/2/node_risks/2`、`/trace_analysis/top_paths/2/node_risks/3`

### evidence-e61

E61 · E_9bec977611dff70b · `/trace_analysis/top_paths/2/bridge_witnesses/1`、`/trace_analysis/top_paths/2/node_risks/3`、`/trace_analysis/top_paths/2/node_risks/4`、`/trace_analysis/top_paths/2/node_risks/5`、`/trace_analysis/top_paths/2/node_risks/6`

### evidence-e62

E62 · E_d43b7335fcfd0240 · `/trace_analysis/top_paths/3`

### evidence-e63

E63 · E_65fcd758fc79ce55 · `/trace_analysis/top_paths/3/node_risks/0`、`/trace_analysis/top_paths/3/nodes/0`

### evidence-e64

E64 · E_efdbba9c3bddd732 · `/trace_analysis/top_paths/3/node_risks/1`、`/trace_analysis/top_paths/3/nodes/1`

### evidence-e65

E65 · E_b43ecfbc290c31c3 · `/trace_analysis/top_paths/3/node_risks/2`、`/trace_analysis/top_paths/3/nodes/2`

### evidence-e66

E66 · E_e15cb8e0fa5395fa · `/trace_analysis/top_paths/3/node_risks/3`、`/trace_analysis/top_paths/3/nodes/3`

### evidence-e67

E67 · E_eaebee78c2f79928 · `/trace_analysis/top_paths/3/node_risks/4`、`/trace_analysis/top_paths/3/nodes/4`

### evidence-e68

E68 · E_274f91a44e3ee2ac · `/trace_analysis/top_paths/3/node_risks/5`、`/trace_analysis/top_paths/3/nodes/5`

### evidence-e69

E69 · E_14e4e3aa86c301b4 · `/trace_analysis/top_paths/3/node_risks/6`、`/trace_analysis/top_paths/3/nodes/6`

### evidence-e70

E70 · E_7b48dbe8b0819042 · `/trace_analysis/top_paths/3/node_risks/7`、`/trace_analysis/top_paths/3/nodes/7`

### evidence-e71

E71 · E_d46879b6ebeb4543 · `/trace_analysis/top_paths/3/node_risks/8`、`/trace_analysis/top_paths/3/nodes/8`

### evidence-e72

E72 · E_ade2a161acce0fc0 · `/trace_analysis/top_paths/3/node_risks/9`、`/trace_analysis/top_paths/3/nodes/9`

### evidence-e73

E73 · E_c41553b1086eac73 · `/trace_analysis/top_paths/3/node_risks/10`、`/trace_analysis/top_paths/3/nodes/10`

### evidence-e74

E74 · E_197693a641c9a91e · `/trace_analysis/top_paths/3/bridge_witnesses/0`、`/trace_analysis/top_paths/3/node_risks/0`、`/trace_analysis/top_paths/3/node_risks/1`、`/trace_analysis/top_paths/3/node_risks/2`、`/trace_analysis/top_paths/3/node_risks/3`

### evidence-e75

E75 · E_6da445b060855e31 · `/trace_analysis/top_paths/3/bridge_witnesses/1`、`/trace_analysis/top_paths/3/node_risks/3`、`/trace_analysis/top_paths/3/node_risks/4`、`/trace_analysis/top_paths/3/node_risks/5`、`/trace_analysis/top_paths/3/node_risks/6`

### evidence-e76

E76 · E_e42fc63ada2a9c20 · `/trace_analysis/top_paths/3/bridge_witnesses/2`、`/trace_analysis/top_paths/3/node_risks/6`、`/trace_analysis/top_paths/3/node_risks/7`、`/trace_analysis/top_paths/3/node_risks/8`、`/trace_analysis/top_paths/3/node_risks/9`、`/trace_analysis/top_paths/3/node_risks/10`

### evidence-e77

E77 · E_f40d47c3ebc8eac8 · `/trace_analysis/top_paths/4`

### evidence-e78

E78 · E_927bf29aa5ac44db · `/trace_analysis/top_paths/4/node_risks/0`、`/trace_analysis/top_paths/4/nodes/0`

### evidence-e79

E79 · E_e35977cd6704f3fc · `/trace_analysis/top_paths/4/node_risks/1`、`/trace_analysis/top_paths/4/nodes/1`

### evidence-e80

E80 · E_a1d9ad299acfdfc9 · `/trace_analysis/top_paths/4/node_risks/2`、`/trace_analysis/top_paths/4/nodes/2`

### evidence-e81

E81 · E_a16d78420de6e653 · `/trace_analysis/top_paths/4/node_risks/3`、`/trace_analysis/top_paths/4/nodes/3`

### evidence-e82

E82 · E_ef8683ca35ffacf2 · `/trace_analysis/top_paths/4/node_risks/4`、`/trace_analysis/top_paths/4/nodes/4`

### evidence-e83

E83 · E_43994b2930cbffd9 · `/trace_analysis/top_paths/4/node_risks/5`、`/trace_analysis/top_paths/4/nodes/5`

### evidence-e84

E84 · E_f549cd767e6bcf72 · `/trace_analysis/top_paths/4/node_risks/6`、`/trace_analysis/top_paths/4/nodes/6`

### evidence-e85

E85 · E_53332358d6fe606f · `/trace_analysis/top_paths/4/node_risks/7`、`/trace_analysis/top_paths/4/nodes/7`

### evidence-e86

E86 · E_dedabcaaf6c86967 · `/trace_analysis/top_paths/4/node_risks/8`、`/trace_analysis/top_paths/4/nodes/8`

### evidence-e87

E87 · E_3288536d241e3a13 · `/trace_analysis/top_paths/4/node_risks/9`、`/trace_analysis/top_paths/4/nodes/9`

### evidence-e88

E88 · E_20a80f640f46eafc · `/trace_analysis/top_paths/4/node_risks/10`、`/trace_analysis/top_paths/4/nodes/10`

### evidence-e89

E89 · E_f64255e3d0104fe8 · `/trace_analysis/top_paths/4/bridge_witnesses/0`、`/trace_analysis/top_paths/4/node_risks/0`、`/trace_analysis/top_paths/4/node_risks/1`、`/trace_analysis/top_paths/4/node_risks/2`、`/trace_analysis/top_paths/4/node_risks/3`

### evidence-e90

E90 · E_aa016f55c3726be0 · `/trace_analysis/top_paths/4/bridge_witnesses/1`、`/trace_analysis/top_paths/4/node_risks/3`、`/trace_analysis/top_paths/4/node_risks/4`、`/trace_analysis/top_paths/4/node_risks/5`、`/trace_analysis/top_paths/4/node_risks/6`

### evidence-e91

E91 · E_c14936c517ebd544 · `/trace_analysis/top_paths/4/bridge_witnesses/2`、`/trace_analysis/top_paths/4/node_risks/6`、`/trace_analysis/top_paths/4/node_risks/7`、`/trace_analysis/top_paths/4/node_risks/8`、`/trace_analysis/top_paths/4/node_risks/9`、`/trace_analysis/top_paths/4/node_risks/10`

### evidence-e92

E92 · E_f19ec485b3995f7c · `/trace_analysis/search_budget`

### evidence-e93

E93 · E_4f534ff4dcdbf5e4 · 系统边界规则：human_review

### evidence-e94

E94 · E_e95b7f07bdbcab1a · 系统边界规则：model_boundary

### evidence-e95

E95 · E_06f13f3d7c0fefb6 · 系统边界规则：relation_boundary

### evidence-e96

E96 · E_abe639cfbc547b64 · 系统边界规则：search_boundary

### evidence-e97

E97 · E_a65fd7f2d5645a7a · 系统边界规则：attribution_boundary

### evidence-e98

E98 · E_90f639097ca44349 · 系统边界规则：calibration_boundary

### evidence-e99

E99 · E_b8e21a2913015653 · 系统边界规则：snapshot_boundary

